# ATTENTION #

The v042 designs for the base board, the E22dual board, and the E28dual board are up-to-date.

The v031 dualSx board will not be updated.


