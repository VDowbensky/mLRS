# mLRS Hardware: Easy-To-Solder Board E77 E22 dual #

For the through-hole parts, Mouser parts numbers are listed in the electric scheme. A list of parts is also available here https://www.mouser.de/ProjectManager/ProjectDetail.aspx?AccessID=b60c19cf3a.

These are of course only suggestions, these and equally suitable parts can be sourced from many places.

The EByte E77-900M22S module is relatively new. It can be ordered from the "EBYTE Official Store" on AliExpress.

The EByte E22-900M22S module is needed only for a true-diversity build. It is around for some while and can be ordered on AliExpress from several sources (the "EBYTE Official Store" may not be the cheapest offer).




